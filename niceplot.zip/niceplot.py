# -*- coding: utf-8 -*-
"""
Created on Tuesday January 14, 2020
Script allows to read and plott several FIT-files from local folderBackground is subtracted
x-axis is presented in DateTime-format
Edit: file, time for bckground subtraction in seconds
Edit: vmin and vmax for color table adjustment and edit color-table in imshow()
Decide for manualzoom. If True, set hour, minute and seconds appropriate for start and stop
and edit frequency range
Edit graphic-file extension if required png, pdf, jpg, ....
Edit rotation angle fir x- and y-axis if required, depends on duration of plot

@author: Christian Monstein
"""
#-------------------------------------------------------------------------------

from astropy.io import fits
import matplotlib.pyplot as plt 
from matplotlib import cm
import numpy as np
import matplotlib.dates as mdates
import datetime as dt
import time
import glob
#-------------------------------------------------------------------------------

MyPath = '' # Edit in case the file is elsewhere, outside local folder, use '/' instead of '\'
MyFile = 'BLENSW_20180330_08????_01.fit.gz'
timecorrection = 1 # to force 'nice' time-axis, shifting image in time, be careful!!!
paths = glob.glob(MyPath+MyFile) # search the folder
paths.sort() # force alphabetical order of the files
print ('\nFIT-files found: ',(len(paths)),paths)
#-------------------------------------------------------------------------------

def get_data_from_fits(path):
    with fits.open(path) as hdu:
        data = hdu[0].data.astype(np.uint8) # float16, float32, uin8 depends on PC
    return data
#-------------------------------------------------------------------------------

with fits.open(paths[0]) as hdu:
    data       = hdu[0].data
    freqs      = hdu[1].data  ['Frequency'][0] # extract frequency axis
    timeax     = hdu[1].data  ['Time'][0]      # extract time axis
    dT         = hdu[0].header['CDELT1']     # extract time resolution
    datum      = hdu[0].header['DATE-OBS']   # take first file
    T0         = hdu[0].header['TIME-OBS']   # take first file
    instrument = hdu[0].header['INSTRUME']
    content    = hdu[0].header['CONTENT']
    # https://docs.astropy.org/en/stable/io/fits/
    print (hdu.info())
    print (hdu[0].header)
    print (hdu[1].header)
    
with fits.open(paths[-1]) as hdu:
    T1 = hdu[0].header['TIME-END']  # take first file

#------------------------------------------------------------------------------

data = np.hstack([get_data_from_fits(path) for path in paths])
print ('Data shape: ',data.shape)

#------------------------------------------------------------------------------

Tmin =  1 # Start time for background averaging [sec]
Tmax = 20 # Stop time for background averaging [sec]
dmean = np.mean(data[:,int(Tmin/dT):int(Tmax/dT)], axis=1,keepdims=True) # all frequencies, time range in pixels
bgs = data - dmean # subtraction background
meanspec = np.mean(bgs) # averafe spectrum
vmin = -5*meanspec # minimum cut for color table, need to play with
vmax = 10*meanspec # maximum cut for color label, need to play with

manualzoom='False'
if (manualzoom):
    zoomTstart=[8,10,0] # start time as hour, minute, second
    zoomTstop =[8,15,0] # stop time as hour, minute, second
    zoomF=[30,70] # frequency range min, max [MHz]
#------------------------------------------------------------------------------

YY = int(datum.split("/")[0])
MM = int(datum.split("/")[1])
DD = int(datum.split("/")[2])

hh = int(T0.split(":")[0])
mm = int(T0.split(":")[1])
ss = int(0.5+float(T0.split(":")[2]))
d0 = dt.datetime(YY,MM,DD,hh,mm,ss-timecorrection)
unixtime0 = time.mktime(d0.timetuple())

hh = int(T1.split(":")[0])
mm = int(T1.split(":")[1])
ss = int(0.5+float(T1.split(":")[2]))
d1 = dt.datetime(YY,MM,DD,hh,mm,ss)
unixtime1 = time.mktime(d1.timetuple())

# Create your x-limits. Using two of your unix timestamps you first
# create a list of datetime.datetime objects using map.
x_lims = list(map(dt.datetime.fromtimestamp, [unixtime0, unixtime1]))

# You can then convert these datetime.datetime objects to the correct
# format for matplotlib to work with.
x_lims = mdates.date2num(x_lims)

# Set some initial y-limits.
y_lims = [freqs[-1],freqs[0]]

fig, ax = plt.subplots(figsize=(12,8))

# Using ax.imshow we set two keyword arguments. The first is extent.
# We give extent the values from x_lims and y_lims above.
# We also set the aspect to "auto" which should set the plot up nicely.
ax.imshow(bgs, extent = [x_lims[0], x_lims[1],  y_lims[0], y_lims[1]], 
          aspect='auto',cmap=cm.magma,norm=plt.Normalize(vmin, vmax))
# https://matplotlib.org/examples/color/colormaps_reference.html
 # jet, CMRmap, gnuplot2, magma, plasma, Spectral

# We tell Matplotlib that the x-axis is filled with datetime data, 
# this converts it from a float (which is the output of date2num) 
# into a nice datetime string.
ax.xaxis_date()

ax.set_xlabel('Observation time [UTC]',fontsize=14)
ax.set_ylabel('Plasma frequency [MHz]',fontsize=14)
#ax.set_title('Callisto: ' + MyFile,fontsize=15)
ax.set_title(content,fontsize=15)

for tick in ax.get_xticklabels():
    tick.set_rotation(0) # 20° ... 45°
    tick.set_size(12)
    
for tick in ax.get_yticklabels():
    tick.set_rotation(0) # 0° or 90°
    tick.set_size(12)

if (manualzoom=='True'):
    ax.set_ylim(zoomF)
    
    d2 = dt.datetime(YY,MM,DD,zoomTstart[0],zoomTstart[1],zoomTstart[2])
    d3 = dt.datetime(YY,MM,DD,zoomTstop[0], zoomTstop[1], zoomTstop[2])
    unixtime2 = time.mktime(d2.timetuple())
    unixtime3 = time.mktime(d3.timetuple())
    x_lims_new = list(map(dt.datetime.fromtimestamp, [unixtime2, unixtime3]))
    
    ax.set_xlim(x_lims_new)
    
    from matplotlib.ticker import (AutoMinorLocator)
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    
    ax.tick_params(which='both' , width =2)
    ax.tick_params(which='major', length=5)
    ax.tick_params(which='minor', length=2, color='blue')

from matplotlib.dates import DateFormatter

fig.gca().xaxis.set_major_formatter( DateFormatter('%H:%M:%S') )

start, end = ax.get_xlim()
deltaT = (end-start)/12
ax.xaxis.set_ticks(np.arange(start, end, deltaT))

fig.tight_layout() # makes x-axis label visible
plt.savefig("MyPlot.png")
